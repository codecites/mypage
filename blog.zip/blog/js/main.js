$(document).ready(function(){
	$(".span").mouseenter(function(){
		$(this).children("ul").css("display","block");
	});
	$(".span").mouseout(function(){
		$(this).children("ul").css("display","");
	});
	$(".span ul").mouseenter(function(){
		$(this).children("li").css("display","block");
	});
	$(".span ul").mouseout(function(){
		$(this).children("li").css("display","");
	});
});