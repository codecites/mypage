function showobj(id){
	var obj=document.getElementById(id);
	obj.style.display="block";
	obj.style.background="#FFFFFF";
}
function hideobj(id){
	var obj=document.getElementById(id);
	obj.style.display="none";
}
function showbcgd(id){
	var obj1=document.getElementById(id);
	obj1.style.background="#f8f8f8";
	obj1.style.color="#f61d48";
}
function hidebcgd(id){
	var obj1=document.getElementById(id);
	obj1.style.background="none";
}
//实例化一个数组，存放图片的路径
 var arr=new Array;
 arr[0]="img/lunbotu3.webp";
 arr[1]="img/lunbotu2.webp";
 arr[2]="img/lunbotu3.webp";
 arr[3]="img/lunbotu4.webp";
 
var count=0;
//切换图片的功能
function autoPlayer(){
	if(arr.length==count)
	count=0;
	document.getElementById("banner1").src=arr[count];
	count++;
	
}
var timer=setInterval(autoPlayer,4000);

//清除功能
function cleartimer(){
	clearInterval(timer);
}

//鼠标悬停时指定播放
function showbannerById(num){
	cleartimer();
	var index=parseFloat(num);
	document.getElementById("banner1").src=arr[index-1];
	count=index;
}

//鼠标离开自动恢复图片切换
function btnMouseout(){
	timer=setInterval(autoPlayer,4000);
}
